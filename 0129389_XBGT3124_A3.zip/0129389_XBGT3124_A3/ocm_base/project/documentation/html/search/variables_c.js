var searchData=
[
  ['width_0',['width',['../struct_kanata_engine_1_1_window_data.html#a084b0dc1d45370af8f590eaaabe4b49b',1,'KanataEngine::WindowData']]],
  ['window_1',['window',['../class_kanata_engine_1_1_app_window.html#a08b68ab99fefe97d0abea97a97a97e63',1,'KanataEngine::AppWindow']]]
];
