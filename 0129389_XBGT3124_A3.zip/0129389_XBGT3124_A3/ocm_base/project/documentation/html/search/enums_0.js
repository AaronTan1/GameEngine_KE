var searchData=
[
  ['windowsevent_0',['WindowsEvent',['../namespace_kanata_engine.html#ac42d3f44723dbeaa771dac301b53a285',1,'KanataEngine']]]
];
