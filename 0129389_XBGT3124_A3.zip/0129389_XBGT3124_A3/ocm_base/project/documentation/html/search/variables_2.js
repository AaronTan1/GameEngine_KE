var searchData=
[
  ['flaggedfordeletion_0',['flaggedForDeletion',['../class_kanata_engine_1_1_base_component.html#a293514935e21c9a11bb4503bc5ccbb8f',1,'KanataEngine::BaseComponent']]],
  ['frameindexlimit_1',['frameIndexLimit',['../class_kanata_engine_1_1_animated_sprite_renderer.html#aed6c5bbd3569faab8df305159aedd19c',1,'KanataEngine::AnimatedSpriteRenderer']]]
];
