var searchData=
[
  ['windowdata_0',['WindowData',['../struct_kanata_engine_1_1_window_data.html',1,'KanataEngine']]]
];
