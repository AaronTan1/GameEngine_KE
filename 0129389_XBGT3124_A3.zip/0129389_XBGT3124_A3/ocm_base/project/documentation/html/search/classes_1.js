var searchData=
[
  ['basecomponent_0',['BaseComponent',['../class_kanata_engine_1_1_base_component.html',1,'KanataEngine']]],
  ['basescene_1',['BaseScene',['../class_kanata_engine_1_1_base_scene.html',1,'KanataEngine']]]
];
