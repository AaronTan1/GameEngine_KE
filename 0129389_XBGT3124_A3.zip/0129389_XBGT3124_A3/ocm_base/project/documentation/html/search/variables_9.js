var searchData=
[
  ['r_0',['r',['../struct_kanata_engine_1_1_vec3.html#a6fdade4e2c736fb153351f4459d720cd',1,'KanataEngine::Vec3::r'],['../namespace_kanata_engine.html#a92715a591e1334b300679450cf525fe0',1,'KanataEngine::r']]],
  ['refcount_1',['refCount',['../class_kanata_engine_1_1_texture.html#a39c4cbf3b891493533111620c39f1f9e',1,'KanataEngine::Texture']]],
  ['rotation_2',['rotation',['../class_kanata_engine_1_1_transform_component.html#a8e8d4415709d28c435a98bf260e5cc01',1,'KanataEngine::TransformComponent']]]
];
