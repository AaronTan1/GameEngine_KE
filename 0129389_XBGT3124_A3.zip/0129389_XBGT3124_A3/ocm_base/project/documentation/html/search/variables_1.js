var searchData=
[
  ['callback_0',['callback',['../struct_kanata_engine_1_1_window_data.html#a95686789a2af32ca3df83a93427a9a81',1,'KanataEngine::WindowData']]]
];
