var searchData=
[
  ['name_0',['name',['../class_game_object.html#af542b33c8de269343e22c5629e6b66c0',1,'GameObject::name'],['../class_kanata_engine_1_1_texture.html#ad87b979b0f196e7d7d3b6a1c3453895c',1,'KanataEngine::Texture::name']]]
];
