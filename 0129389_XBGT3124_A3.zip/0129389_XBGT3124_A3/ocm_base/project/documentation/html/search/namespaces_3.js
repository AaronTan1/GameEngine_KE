var searchData=
[
  ['kanataengine_0',['KanataEngine',['../namespace_kanata_engine.html',1,'']]]
];
