var searchData=
[
  ['window_5fclose_5fcallback_0',['window_close_callback',['../class_kanata_engine_1_1_application.html#afb489d60e0474f1f7431b5ecc68e7c6a',1,'KanataEngine::Application']]]
];
