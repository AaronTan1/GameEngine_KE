var searchData=
[
  ['deactivate_0',['deactivate',['../class_kanata_engine_1_1_base_scene.html#a84d77e33f5aaa6abb6753cc81b566b4a',1,'KanataEngine::BaseScene']]],
  ['decreaserefcount_1',['decreaseRefCount',['../class_kanata_engine_1_1_texture.html#a9c6f410eb10166f11d0c1c7cd58edde6',1,'KanataEngine::Texture']]],
  ['deletetexture_2',['deleteTexture',['../class_kanata_engine_1_1_texture_allocator.html#a503a048e882092d053efd631dd9aee1f',1,'KanataEngine::TextureAllocator']]],
  ['destroy_3',['destroy',['../class_kanata_engine_1_1_base_component.html#a19d45b99808070e46ec1fb6a55f1b205',1,'KanataEngine::BaseComponent::destroy()'],['../class_game_object.html#a16bed5462eb42d7c42ef2aea5d4df76d',1,'GameObject::destroy()']]],
  ['dispose_4',['dispose',['../class_kanata_engine_1_1_game_object_collection.html#ab6b10c203e85be783c3487ffde76619e',1,'KanataEngine::GameObjectCollection::dispose()'],['../class_kanata_engine_1_1_scene_state_machine.html#a1fdf81e2ac8514f9b5a55e8369f662b2',1,'KanataEngine::SceneStateMachine::dispose()']]],
  ['draw_5',['draw',['../class_kanata_engine_1_1_sprite_renderer_component.html#aec6672f019970f1e0c982a2fa23880b6',1,'KanataEngine::SpriteRendererComponent']]]
];
