var struct_kanata_engine_1_1_vec2 =
[
    [ "x", "struct_kanata_engine_1_1_vec2.html#a771f28cd4660b71280d2504208a1419f", null ],
    [ "y", "struct_kanata_engine_1_1_vec2.html#a997a1e41b048369d0bdb81b258ef8f2c", null ]
];