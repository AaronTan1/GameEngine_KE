var namespaces_dup =
[
    [ "AnimationShowcaseScene", "namespace_animation_showcase_scene.html", "namespace_animation_showcase_scene" ],
    [ "FirstScene", "namespace_first_scene.html", "namespace_first_scene" ],
    [ "GameScene", "namespace_game_scene.html", null ],
    [ "KanataEngine", "namespace_kanata_engine.html", "namespace_kanata_engine" ],
    [ "LoadingScene", "namespace_loading_scene.html", "namespace_loading_scene" ],
    [ "SecondScene", "namespace_second_scene.html", "namespace_second_scene" ],
    [ "SplashArtScene", "namespace_splash_art_scene.html", "namespace_splash_art_scene" ]
];