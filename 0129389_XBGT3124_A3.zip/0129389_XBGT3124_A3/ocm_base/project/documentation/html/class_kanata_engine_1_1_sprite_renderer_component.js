var class_kanata_engine_1_1_sprite_renderer_component =
[
    [ "SpriteRendererComponent", "class_kanata_engine_1_1_sprite_renderer_component.html#a3dc8ebdc77bee54c9fccd01e5d45993c", null ],
    [ "~SpriteRendererComponent", "class_kanata_engine_1_1_sprite_renderer_component.html#ad939143fb566bb65b0637318a2037e35", null ],
    [ "draw", "class_kanata_engine_1_1_sprite_renderer_component.html#aec6672f019970f1e0c982a2fa23880b6", null ],
    [ "setColour", "class_kanata_engine_1_1_sprite_renderer_component.html#a6fbfb31846187877dfea75256f64b8dd", null ],
    [ "setColour", "class_kanata_engine_1_1_sprite_renderer_component.html#a6b1f505d8f42627c31126c14913e52f9", null ],
    [ "setOpacity", "class_kanata_engine_1_1_sprite_renderer_component.html#a32e353af408eb7f264cd857e6f54df77", null ],
    [ "setPivot", "class_kanata_engine_1_1_sprite_renderer_component.html#a96b294cc6f41cdce6659825177be35fb", null ],
    [ "setPivot", "class_kanata_engine_1_1_sprite_renderer_component.html#a7a4624c1c8068533aff612f933f82273", null ],
    [ "setSize", "class_kanata_engine_1_1_sprite_renderer_component.html#a881997fbb9734ab9d307a6bee63ae1fb", null ],
    [ "setSize", "class_kanata_engine_1_1_sprite_renderer_component.html#a479c38c52169717b1dcfe5fe5acc6d74", null ],
    [ "texture", "class_kanata_engine_1_1_sprite_renderer_component.html#a0f1b545b464bf82849340636cdc65a73", null ]
];