var struct_kanata_engine_1_1_vector2 =
[
    [ "x", "struct_kanata_engine_1_1_vector2.html#a8ec919c57d091e478144de203f05fae0", null ],
    [ "y", "struct_kanata_engine_1_1_vector2.html#a1219fc8cb7ec78e318e1fb559bf88aa0", null ]
];