var namespace_second_scene =
[
    [ "GameSceneOne", "class_second_scene_1_1_game_scene_one.html", "class_second_scene_1_1_game_scene_one" ],
    [ "ObjScale", "namespace_second_scene.html#af3aafeb9f8f66daeb4f514b58d3191b0", null ],
    [ "spriteRenderComponents", "namespace_second_scene.html#a31019cfd54b3a3a2cbd66c77cf002c26", null ],
    [ "sprite", "namespace_second_scene.html#a76a6c2df2d41b33d36f7b9265c85977b", null ]
];