var class_kanata_engine_1_1_app_window =
[
    [ "~AppWindow", "class_kanata_engine_1_1_app_window.html#aec0316788d9340ed874965b8b5438e31", null ],
    [ "create", "class_kanata_engine_1_1_app_window.html#aa4730f3177181b661563a35e33ce70c2", null ],
    [ "setWindowEventCallback", "class_kanata_engine_1_1_app_window.html#a6db4a8214936ab831ea3cad72bbdd2fa", null ],
    [ "swap_and_poll", "class_kanata_engine_1_1_app_window.html#a017078f911865ac9d0b7b1a8783e08a7", null ]
];