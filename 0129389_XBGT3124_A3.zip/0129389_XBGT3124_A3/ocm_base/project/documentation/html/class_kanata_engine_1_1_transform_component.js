var class_kanata_engine_1_1_transform_component =
[
    [ "TransformComponent", "class_kanata_engine_1_1_transform_component.html#aa1bab52dfe6b0f617f31709067eaa341", null ],
    [ "~TransformComponent", "class_kanata_engine_1_1_transform_component.html#a90fb1f1557a31624c99bbae7eb4b8068", null ],
    [ "awake", "class_kanata_engine_1_1_transform_component.html#a18a385afbf9fa1c1f37cf1058c6f6b68", null ],
    [ "getRotation", "class_kanata_engine_1_1_transform_component.html#a650b4be9ff2c5c2bb2dff0064c4266e0", null ],
    [ "getX", "class_kanata_engine_1_1_transform_component.html#a8c4dca2e161a899bdecde1105d23ee49", null ],
    [ "getY", "class_kanata_engine_1_1_transform_component.html#ab32dc68666f35955b00549da0dadc63d", null ],
    [ "render", "class_kanata_engine_1_1_transform_component.html#a6f1daa9cc679f8c9264e5ebc64da554d", null ],
    [ "setRotation", "class_kanata_engine_1_1_transform_component.html#abd5064386fcba84fbbb37e5297819cde", null ],
    [ "setX", "class_kanata_engine_1_1_transform_component.html#a9a21f887537812852f7e92bd9fff56ca", null ],
    [ "setY", "class_kanata_engine_1_1_transform_component.html#a3aa27b92284d32d465c3f5db6c3bc335", null ],
    [ "start", "class_kanata_engine_1_1_transform_component.html#a9240d8344c605b450a6dc54e6ed4f37b", null ],
    [ "update", "class_kanata_engine_1_1_transform_component.html#ad2af547ed98b9832d647c00a9db4c5b8", null ],
    [ "rotation", "class_kanata_engine_1_1_transform_component.html#a8e8d4415709d28c435a98bf260e5cc01", null ],
    [ "x", "class_kanata_engine_1_1_transform_component.html#ac602531ee695c2ffb879aeca3269eb0e", null ],
    [ "y", "class_kanata_engine_1_1_transform_component.html#a4e47da586ff157e8c0c2fcf4760762e5", null ]
];