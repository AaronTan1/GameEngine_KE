var struct_kanata_engine_1_1_window_data =
[
    [ "callback", "struct_kanata_engine_1_1_window_data.html#a95686789a2af32ca3df83a93427a9a81", null ],
    [ "height", "struct_kanata_engine_1_1_window_data.html#aec0540e6439ea0cb4311449f8f0c92a0", null ],
    [ "title", "struct_kanata_engine_1_1_window_data.html#a1eecb0cc7804a246fff3b527c24254c1", null ],
    [ "width", "struct_kanata_engine_1_1_window_data.html#a084b0dc1d45370af8f590eaaabe4b49b", null ]
];